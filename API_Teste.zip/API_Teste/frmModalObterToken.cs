﻿using API_Teste.Classes;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using API_Teste.Properties;

namespace API_Teste
{
    public partial class frmModalObterToken : Form
    {
        public frmModalObterToken()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void frmModalObterToken_Load(object sender, EventArgs e)
        {
            grdObterTokenParams.Rows.Clear();
            txtJsonObjetoOrigemToken.Text = "access_token";

            #region Carregar Dados Salvos
            if (!string.IsNullOrEmpty(Settings.Default.TokenParams))
            {
                clsDadosToken.ParametrosObtenção = JsonConvert.DeserializeObject<List<KeyValuePair<string, string>>>(Settings.Default.TokenParams);
                clsDadosToken.Uri = Settings.Default.TokenUri;
                clsDadosToken.Token = Settings.Default.TokenValue;
            }
            #endregion


            if (string.IsNullOrEmpty(clsDadosToken.Token))
            {
                grdObterTokenParams.Rows.Add("grant_type", "password");
                grdObterTokenParams.Rows.Add("username", "");
                grdObterTokenParams.Rows.Add("password", "");
            }
            else
            {
                txtToken.Text = clsDadosToken.Token;
                txtObterTokenUri.Text = clsDadosToken.Uri;

                foreach (var param in clsDadosToken.ParametrosObtenção)
                {
                    grdObterTokenParams.Rows.Add(param.Key, param.Value);
                }
            }
        }

        private void btnObterToken_Click(object sender, EventArgs e)
        {
            lblMensagem.Text = "Aguarde ...";
            txtToken.Text = ObterDadosToken();
            lblMensagem.Text = (lblMensagem.Text.Equals("Aguarde ...") ? "Pronto." : lblMensagem.Text);
        }


        private string ObterDadosToken()
        {

            string conteudoString = string.Empty;

            try
            {

                HttpResponseMessage tokenResponse;

                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Clear();

                    if (rdbPost.Checked)
                    {

                        var form = new Dictionary<string, string>();
                        foreach (DataGridViewRow linha in grdObterTokenParams.Rows)
                        {
                            form.Add(linha.Cells[0].FormattedValue.ToString(), linha.Cells[1].FormattedValue.ToString());
                        }
                        var httpContent = new FormUrlEncodedContent(form);
                        tokenResponse = client.PostAsync(new Uri(txtObterTokenUri.Text), new FormUrlEncodedContent(form)).Result;
                    }
                    else
                    {
                        tokenResponse = client.GetAsync(new Uri(txtObterTokenUri.Text)).Result;
                    }

                    conteudoString = tokenResponse.Content.ReadAsStringAsync().Result;


                    if (tokenResponse.StatusCode != HttpStatusCode.OK)
                    {
                        lblMensagem.Text = "Falha na Requisição: " + tokenResponse.StatusCode.ToString();
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(conteudoString))
                        {
                            if (tokenResponse.Content.Headers.ContentType.MediaType.Equals("application/json"))
                            {
                                using (StreamReader reader = new StreamReader(tokenResponse.Content.ReadAsStreamAsync().Result))
                                {
                                    var jsonString = reader.ReadToEnd();
                                    var json = JsonConvert.DeserializeObject<JObject>(jsonString);
                                    try
                                    {
                                        conteudoString = json.SelectToken(txtJsonObjetoOrigemToken.Text).ToString();
                                    }
                                    catch
                                    {
                                        conteudoString = jsonString;
                                    }
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                lblMensagem.Text = ex.Message;
            }

            return conteudoString;
        }

       

        private void btnSalvar_Click(object sender, EventArgs e)
        {

            //Inicializa objeto estático
            clsDadosToken.Uri = string.Empty;
            clsDadosToken.Token = string.Empty;
            clsDadosToken.ParametrosObtenção = new List<KeyValuePair<string, string>>();

            //Carrega objeto estático
            clsDadosToken.Token = txtToken.Text;
            clsDadosToken.Uri = txtObterTokenUri.Text;
            foreach (DataGridViewRow linha in grdObterTokenParams.Rows)
            {
                if (!string.IsNullOrEmpty(linha.Cells[0].FormattedValue.ToString()))//salva apenas com contém valor na coluna 'parâmetro'
                {
                    clsDadosToken.ParametrosObtenção.Add(new KeyValuePair<string, string>(linha.Cells[0].FormattedValue.ToString(), linha.Cells[1].FormattedValue.ToString()));
                }
            }

            string jsonTokenParams = JsonConvert.SerializeObject(API_Teste.Classes.clsDadosToken.ParametrosObtenção);
            string strTokenUri = API_Teste.Classes.clsDadosToken.Uri;
            string strToken = API_Teste.Classes.clsDadosToken.Token;

            //Salva em Settings da Aplicação, por usuário
            Settings.Default.TokenParams = jsonTokenParams;
            Settings.Default.TokenUri = strTokenUri;
            Settings.Default.TokenValue = strToken;
            Settings.Default.Save();

            lblMensagem.Text = "Salvo.";

        }
    }
}
