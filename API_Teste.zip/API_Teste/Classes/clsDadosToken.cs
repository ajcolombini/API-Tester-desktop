﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_Teste.Classes
{
    public static class clsDadosToken
    {
        public static string Uri { get; set; }
        public static List<KeyValuePair<string, string>> ParametrosObtenção { get; set; }
        public static string Token { get; set; }

       
    }
}
