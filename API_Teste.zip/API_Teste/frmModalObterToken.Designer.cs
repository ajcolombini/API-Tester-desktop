﻿namespace API_Teste
{
    partial class frmModalObterToken
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFecharModal = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtObterTokenUri = new System.Windows.Forms.TextBox();
            this.grpParamsToken = new System.Windows.Forms.GroupBox();
            this.grdObterTokenParams = new System.Windows.Forms.DataGridView();
            this.Parâmetro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Valor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnObterToken = new System.Windows.Forms.Button();
            this.txtToken = new System.Windows.Forms.TextBox();
            this.grpMetodo = new System.Windows.Forms.GroupBox();
            this.rdbGet = new System.Windows.Forms.RadioButton();
            this.rdbPost = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtJsonObjetoOrigemToken = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.grpParamsToken.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdObterTokenParams)).BeginInit();
            this.grpMetodo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFecharModal
            // 
            this.btnFecharModal.Location = new System.Drawing.Point(863, 442);
            this.btnFecharModal.Name = "btnFecharModal";
            this.btnFecharModal.Size = new System.Drawing.Size(75, 23);
            this.btnFecharModal.TabIndex = 0;
            this.btnFecharModal.Text = "Fechar";
            this.btnFecharModal.UseVisualStyleBackColor = true;
            this.btnFecharModal.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Uri Token";
            // 
            // txtObterTokenUri
            // 
            this.txtObterTokenUri.Location = new System.Drawing.Point(92, 10);
            this.txtObterTokenUri.Name = "txtObterTokenUri";
            this.txtObterTokenUri.Size = new System.Drawing.Size(846, 20);
            this.txtObterTokenUri.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtObterTokenUri, "Caminho para chamada de obtenção do token");
            // 
            // grpParamsToken
            // 
            this.grpParamsToken.Controls.Add(this.grdObterTokenParams);
            this.grpParamsToken.Location = new System.Drawing.Point(16, 95);
            this.grpParamsToken.Name = "grpParamsToken";
            this.grpParamsToken.Size = new System.Drawing.Size(922, 156);
            this.grpParamsToken.TabIndex = 4;
            this.grpParamsToken.TabStop = false;
            this.grpParamsToken.Text = "Parâmetros";
            // 
            // grdObterTokenParams
            // 
            this.grdObterTokenParams.BackgroundColor = System.Drawing.SystemColors.Control;
            this.grdObterTokenParams.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdObterTokenParams.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Parâmetro,
            this.Valor});
            this.grdObterTokenParams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdObterTokenParams.Location = new System.Drawing.Point(3, 16);
            this.grdObterTokenParams.Name = "grdObterTokenParams";
            this.grdObterTokenParams.Size = new System.Drawing.Size(916, 137);
            this.grdObterTokenParams.TabIndex = 0;
            this.toolTip1.SetToolTip(this.grdObterTokenParams, "Informe os parâmetros da chamada para obtenção do token");
            // 
            // Parâmetro
            // 
            this.Parâmetro.HeaderText = "Parâmetro";
            this.Parâmetro.Name = "Parâmetro";
            // 
            // Valor
            // 
            this.Valor.HeaderText = "Valor";
            this.Valor.Name = "Valor";
            // 
            // btnObterToken
            // 
            this.btnObterToken.Location = new System.Drawing.Point(831, 257);
            this.btnObterToken.Name = "btnObterToken";
            this.btnObterToken.Size = new System.Drawing.Size(104, 23);
            this.btnObterToken.TabIndex = 5;
            this.btnObterToken.Text = "Obter novo token";
            this.btnObterToken.UseVisualStyleBackColor = true;
            this.btnObterToken.Click += new System.EventHandler(this.btnObterToken_Click);
            // 
            // txtToken
            // 
            this.txtToken.Location = new System.Drawing.Point(19, 288);
            this.txtToken.Multiline = true;
            this.txtToken.Name = "txtToken";
            this.txtToken.ReadOnly = true;
            this.txtToken.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtToken.Size = new System.Drawing.Size(919, 144);
            this.txtToken.TabIndex = 6;
            // 
            // grpMetodo
            // 
            this.grpMetodo.Controls.Add(this.rdbGet);
            this.grpMetodo.Controls.Add(this.rdbPost);
            this.grpMetodo.Location = new System.Drawing.Point(19, 42);
            this.grpMetodo.Name = "grpMetodo";
            this.grpMetodo.Size = new System.Drawing.Size(242, 47);
            this.grpMetodo.TabIndex = 7;
            this.grpMetodo.TabStop = false;
            this.grpMetodo.Text = "Método";
            // 
            // rdbGet
            // 
            this.rdbGet.AutoSize = true;
            this.rdbGet.Location = new System.Drawing.Point(146, 20);
            this.rdbGet.Name = "rdbGet";
            this.rdbGet.Size = new System.Drawing.Size(42, 17);
            this.rdbGet.TabIndex = 1;
            this.rdbGet.Text = "Get";
            this.rdbGet.UseVisualStyleBackColor = true;
            // 
            // rdbPost
            // 
            this.rdbPost.AutoSize = true;
            this.rdbPost.Checked = true;
            this.rdbPost.Location = new System.Drawing.Point(43, 19);
            this.rdbPost.Name = "rdbPost";
            this.rdbPost.Size = new System.Drawing.Size(46, 17);
            this.rdbPost.TabIndex = 0;
            this.rdbPost.TabStop = true;
            this.rdbPost.Text = "Post";
            this.rdbPost.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Retorno";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(768, 442);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(75, 23);
            this.btnSalvar.TabIndex = 9;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // lblMensagem
            // 
            this.lblMensagem.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensagem.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblMensagem.Location = new System.Drawing.Point(15, 441);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(734, 23);
            this.lblMensagem.TabIndex = 14;
            this.lblMensagem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtJsonObjetoOrigemToken);
            this.groupBox1.Location = new System.Drawing.Point(284, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 47);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Objeto Json para captura do Token";
            // 
            // txtJsonObjetoOrigemToken
            // 
            this.txtJsonObjetoOrigemToken.Location = new System.Drawing.Point(16, 20);
            this.txtJsonObjetoOrigemToken.Name = "txtJsonObjetoOrigemToken";
            this.txtJsonObjetoOrigemToken.Size = new System.Drawing.Size(245, 20);
            this.txtJsonObjetoOrigemToken.TabIndex = 0;
            this.toolTip1.SetToolTip(this.txtJsonObjetoOrigemToken, "Informe o nome da entrada no Json retornado, que contém o token");
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 150;
            this.toolTip1.ReshowDelay = 100;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // frmModalObterToken
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 469);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grpMetodo);
            this.Controls.Add(this.txtToken);
            this.Controls.Add(this.btnObterToken);
            this.Controls.Add(this.grpParamsToken);
            this.Controls.Add(this.txtObterTokenUri);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFecharModal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmModalObterToken";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Obter Token";
            this.Load += new System.EventHandler(this.frmModalObterToken_Load);
            this.grpParamsToken.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdObterTokenParams)).EndInit();
            this.grpMetodo.ResumeLayout(false);
            this.grpMetodo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFecharModal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtObterTokenUri;
        private System.Windows.Forms.GroupBox grpParamsToken;
        private System.Windows.Forms.Button btnObterToken;
        private System.Windows.Forms.TextBox txtToken;
        private System.Windows.Forms.GroupBox grpMetodo;
        private System.Windows.Forms.RadioButton rdbGet;
        private System.Windows.Forms.RadioButton rdbPost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.DataGridView grdObterTokenParams;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parâmetro;
        private System.Windows.Forms.DataGridViewTextBoxColumn Valor;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtJsonObjetoOrigemToken;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}