﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using API_Teste.Classes;
using API_Teste.Properties;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace API_Teste
{
    public partial class formPrincipal : Form
    {
        NameValueCollection ColecaoParametros { get; set; }

        public formPrincipal()
        {
            InitializeComponent();
        }

        private void ExpandirColunasGrid(DataGridView grd)
        {
            //Expandir colunas ao tamanho do conteúdo
            foreach (DataGridViewColumn column in grd.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                column.Width = column.Width; //This is important, otherwise the following line will nullify your previous command
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }


        private void btnAcessar_Click(object sender, EventArgs e)
        {
            lblMensagem.Text = "Aguarde ...";
            LimparFormulario();

            string token = string.Empty;
            string usuário = string.Empty;
            string senha = string.Empty;
            
            CarregarParametros();

            string uri = txtUrl.Text;
            string tipoAutorização = cboTipoAutorizacao.SelectedItem.ToString();

            switch (tipoAutorização)
            {
                case "TOKEN":
                    token = txtAutorizacaoToken.Text;
                    if (string.IsNullOrEmpty(token.Trim()))
                    {
                        tabCtrlRetornos.SelectedIndex = 0;
                        txtLog.Text = "Token não informado";
                        lblMensagem.Text = "Token não informado";
                        return;
                    }

                    break;


                case "BÁSICA":
                    usuário = txtAutenticacaoUsuario.Text;
                    senha = txtAutenticacaoSenha.Text;

                    if (string.IsNullOrEmpty(usuário.Trim()) | string.IsNullOrEmpty(senha))
                    {
                        tabCtrlRetornos.SelectedIndex = 0;
                        txtLog.Text = "Usuário ou Senha não informados";
                        lblMensagem.Text = "Usuário ou Senha não informados";
                        return;
                    }

                    break;

                default:
                    break;
            }

            HttpMethod método = new HttpMethod(cboMetodo.SelectedItem.ToString());

            grdDados.DataSource = ObterDados(uri, método, token, usuário, senha);

            ExpandirColunasGrid(grdDados);

            lblRetornoLinhas.Text = grdDados.Rows.Count.ToString() + " linhas";

            if (grdDados.Rows.Count == 0)
            {
                lblMensagem.Text = "Terminado  [Sem Resultados]";
            }
            else
            {
                lblMensagem.Text = "Terminado.";
            }

        }

        private void LimparFormulario()
        {
            grdDados.DataSource = null;
            lblRetornoLinhas.Text = string.Empty;
            txtTipoSaida.Text = string.Empty;
            txtLog.Text = string.Empty;
            txtSaída.Text = string.Empty;
            lblMsgSaida.Text = string.Empty;
        }

        private Object ObterDados(string uri, HttpMethod método, string token, string usuário, string senha)
        {

            Object retorno = null;
            StreamReader reader = null;
            String strConteudo = string.Empty;
            DataTable tabelaDados = new DataTable();

            try
            {

                grdCabeçalhos.Rows.Clear();

                #region Chamada

                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Clear();

                    var request = new HttpRequestMessage()
                    {
                        Method = método,
                        RequestUri = new Uri(uri),
                    };

                    if (método.Equals(HttpMethod.Post))
                    {
                        var form = new Dictionary<string, string>();
                        foreach (DataGridViewRow linha in grdParametros.Rows)
                        {
                            if (!string.IsNullOrEmpty(linha.Cells[1].FormattedValue.ToString()))
                            {
                                form.Add(linha.Cells[0].FormattedValue.ToString(), linha.Cells[1].FormattedValue.ToString());
                            }
                        }
                        var httpContent = new FormUrlEncodedContent(form);
                        request.Content = httpContent;
                    }


                    if (!string.IsNullOrEmpty(token))
                    {
                        request.Headers.Add("Authorization", $"Bearer {token}");
                    }

                    if (!string.IsNullOrEmpty(usuário) && !string.IsNullOrEmpty(senha))
                    {
                        var plainTextBytes = Encoding.UTF8.GetBytes(usuário + ":" + senha);
                        string val = Convert.ToBase64String(plainTextBytes);
                        request.Headers.Add("Authorization", $"Basic {val}");
                    }

                    #region Alimenta grid Cabeçalhos
                    foreach (var item in request.Headers)
                    {
                        grdCabeçalhos.Rows.Add(item.Key, String.Join(" ", item.Value));
                    }

                    ExpandirColunasGrid(grdCabeçalhos);
                    #endregion

                    var response = client.SendAsync(request).ConfigureAwait(false).GetAwaiter().GetResult();
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        txtLog.Text = "Falha na requisição" + Environment.NewLine;
                    }

                    if (response.Content.Headers.ContentType.MediaType.Equals("text/xml"))
                    {
                        tabelaDados.ReadXml(response.Content.ReadAsStreamAsync().Result);
                    }

                    if (response.Content.Headers.ContentType.MediaType.Equals("application/json"))
                    {
                        reader = new StreamReader(response.Content.ReadAsStreamAsync().Result);
                        strConteudo = reader.ReadToEnd();
                    }

                    txtTipoSaida.Text = response.Content.Headers.ContentType.MediaType;

                    reader = new StreamReader(response.Content.ReadAsStreamAsync().Result);
                    var conteudoString = reader.ReadToEnd();

                    txtSaída.Text = conteudoString;
                    txtLog.Text = "Status Code: " + response.StatusCode.ToString() + Environment.NewLine;

                }
                #endregion


                if (tabelaDados.Rows.Count == 0)
                {
                    txtSaída.Text = strConteudo;

                    if (!strConteudo.First().Equals('[')) //DeserializeObject, para JArray, funciona com arrays apenas
                    {
                        strConteudo = "[" + strConteudo + "]";
                    }

                    JArray conteudo = JsonConvert.DeserializeObject<JArray>(strConteudo);
                    retorno = conteudo;
                }
                else
                {
                    retorno = tabelaDados;
                }

            }
            catch (Exception ex)
            {
                txtLog.Text += (ex.InnerException != null ? ex.InnerException.ToString() : ex.Message);
                tabCtrlRetornos.SelectedIndex = 0;
                lblMensagem.Text = "Finalizado com Erros";
            }

            return retorno;
        }


        private void formPrincipal_Load(object sender, EventArgs e)
        {
            int res = -1;
            res = cboMetodo.FindStringExact("GET");
            cboMetodo.SelectedIndex = res;
            cboTipoAutorizacao.SelectedIndex = 0;

            if (!string.IsNullOrEmpty(Settings.Default.TokenValue))
            {
                txtAutorizacaoToken.Text = Settings.Default.TokenValue;
            }

            stsLblRodape.Text = "vrs. " + Application.ProductVersion;
        }

        private void cboTipoAutorizacao_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selecionado = cboTipoAutorizacao.SelectedItem;

            switch (selecionado)
            {
                case "BÁSICA":
                    grpAutenticacao.Visible = true;
                    grpToken.Visible = false;
                    break;

                case "TOKEN":
                    grpAutenticacao.Visible = false;
                    grpToken.Visible = true;
                    break;

                default:
                    grpAutenticacao.Visible = false;
                    grpToken.Visible = false;
                    break;
            }


        }

        private void txtUrl_TextChanged(object sender, EventArgs e)
        {
            // CarregarParametros();
        }

        private void CarregarParametros()
        {
            string url = txtUrl.Text;
            var arrUrl = url.Split('?');
            ColecaoParametros = null;

            grdParametros.Rows.Clear();

            if (arrUrl.Length == 2)
            {
                var strParam = arrUrl[1];
                ColecaoParametros = HttpUtility.ParseQueryString(strParam);
            }

            if (ColecaoParametros != null)
            {

                var items = ColecaoParametros.AllKeys.SelectMany(ColecaoParametros.GetValues, (k, v) => new { key = k, value = v });
                foreach (var item in items)
                {
                    grdParametros.AllowUserToAddRows = true;

                    var row = (DataGridViewRow)grdParametros.Rows[0].Clone();
                    row.Cells[0].Value = item.key;
                    row.Cells[1].Value = item.value;

                    grdParametros.Rows.Add(row);
                }

                ExpandirColunasGrid(grdParametros);
            }
        }


        private void grdParametros_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (ColecaoParametros != null)
            {
                var parametrosIniciais = ColecaoParametros.AllKeys.SelectMany(ColecaoParametros.GetValues, (k, v) => new { key = k, value = v });

                string novaUriBase = txtUrl.Text.Split('?')[0];
                string novaUriParams = ""; //txtUrl.Text.Split('?')[1];

                string paramName = grdParametros.Rows[e.RowIndex].Cells[0].Value.ToString();
                string paramValue = grdParametros.Rows[e.RowIndex].Cells[1].Value.ToString();

                var paramArray = parametrosIniciais.ToArray();
                paramArray[e.RowIndex] = new { key = paramName, value = paramValue };

                foreach (var item in paramArray)
                {
                    novaUriParams += "&" + item.key + "=" + item.value;
                }
                novaUriParams = "?" + novaUriParams.Substring(1, novaUriParams.Length - 1);
                txtUrl.Text = novaUriBase + novaUriParams;
            }
        }

        private void btnAutorizacaoMostrarSenha_Click(object sender, EventArgs e)
        {

            if (txtAutenticacaoSenha.UseSystemPasswordChar == true)
            {
                txtAutenticacaoSenha.UseSystemPasswordChar = PasswordPropertyTextAttribute.No.Password;
                btnAutorizacaoMostrarSenha.Text = "Esconder";
            }
            else
            {
                //Hides Textbox password
                txtAutenticacaoSenha.UseSystemPasswordChar = PasswordPropertyTextAttribute.Yes.Password;
                btnAutorizacaoMostrarSenha.Text = "Mostrar";
            }
        }

        private void btnAutorizacaoLimparToken_Click(object sender, EventArgs e)
        {
            txtAutorizacaoToken.Text = string.Empty;
        }

        private void btnUrlLimpar_Click(object sender, EventArgs e)
        {
            txtUrl.Text = string.Empty;
            lblMensagem.Text = string.Empty;
        }

        private void btnObterToken_Click(object sender, EventArgs e)
        {

            frmModalObterToken frm = new frmModalObterToken();
            frm.ShowDialog(this);
            frm.Dispose();
        }


        private void formPrincipal_Activated(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(clsDadosToken.Token))
            {
                txtAutorizacaoToken.Text = clsDadosToken.Token;
            }
        }

        private void cboMetodo_SelectedIndexChanged(object sender, EventArgs e)
        {

            /* Não está salvando celulas editadas no grid - manter params na url sempre */

            //if (cboMetodo.SelectedItem.Equals("POST"))
            //{
            //    string url = txtUrl.Text;
            //    var arrUrl = url.Split('?');
            //    if (arrUrl.Length == 2)
            //    {
            //        txtUrl.Text = arrUrl[0];
            //    }
            //}
            //else
            //{
            //    if (grdParametros.Rows.Count > 0 && ColecaoParametros!=null)
            //    {
            //        var parametrosIniciais = ColecaoParametros.AllKeys.SelectMany(ColecaoParametros.GetValues, (k, v) => new { key = k, value = v });

            //        string novaUriBase = txtUrl.Text.Split('?')[0];
            //        string novaUriParams = "";

            //        var paramArray = parametrosIniciais.ToArray();
  
            //        foreach (var item in paramArray)
            //        {
            //            novaUriParams += "&" + item.key + "=" + item.value;
            //        }
            //        novaUriParams = "?" + novaUriParams.Substring(1, novaUriParams.Length - 1);
            //        txtUrl.Text = novaUriBase + novaUriParams;
            //    }

            //}
        }

        private void btnCopiarSaida_Click(object sender, EventArgs e)
        {
            //salva no clipboard
            Clipboard.SetData(DataFormats.Text, (Object)txtSaída.Text);

            lblMsgSaida.Text = "Copiado.";
        }
    }

}
