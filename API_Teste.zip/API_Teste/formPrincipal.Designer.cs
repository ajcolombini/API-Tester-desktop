﻿namespace API_Teste
{
    partial class formPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formPrincipal));
            this.lblURL = new System.Windows.Forms.Label();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.btnAcessar = new System.Windows.Forms.Button();
            this.grdDados = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.tabCtrlParams = new System.Windows.Forms.TabControl();
            this.tabAutorizacao = new System.Windows.Forms.TabPage();
            this.grpToken = new System.Windows.Forms.GroupBox();
            this.btnObterToken = new System.Windows.Forms.Button();
            this.btnAutorizacaoLimparToken = new System.Windows.Forms.Button();
            this.txtAutorizacaoToken = new System.Windows.Forms.TextBox();
            this.txtAutorizacaoEsquema = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cboTipoAutorizacao = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpAutenticacao = new System.Windows.Forms.GroupBox();
            this.btnAutorizacaoMostrarSenha = new System.Windows.Forms.Button();
            this.txtAutenticacaoSenha = new System.Windows.Forms.TextBox();
            this.txtAutenticacaoUsuario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabParams = new System.Windows.Forms.TabPage();
            this.grdParametros = new System.Windows.Forms.DataGridView();
            this.Parâmetro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Valor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabHeaders = new System.Windows.Forms.TabPage();
            this.grdCabeçalhos = new System.Windows.Forms.DataGridView();
            this.Key = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabCtrlRetornos = new System.Windows.Forms.TabControl();
            this.tabLog = new System.Windows.Forms.TabPage();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.tabSaida = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTipoSaida = new System.Windows.Forms.TextBox();
            this.txtSaída = new System.Windows.Forms.TextBox();
            this.cboMetodo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblRetornoLinhas = new System.Windows.Forms.Label();
            this.btnUrlLimpar = new System.Windows.Forms.Button();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.btnCopiarSaida = new System.Windows.Forms.Button();
            this.lblMsgSaida = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsLblRodape = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.grdDados)).BeginInit();
            this.tabCtrlParams.SuspendLayout();
            this.tabAutorizacao.SuspendLayout();
            this.grpToken.SuspendLayout();
            this.grpAutenticacao.SuspendLayout();
            this.tabParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdParametros)).BeginInit();
            this.tabHeaders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdCabeçalhos)).BeginInit();
            this.tabCtrlRetornos.SuspendLayout();
            this.tabLog.SuspendLayout();
            this.tabSaida.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblURL
            // 
            this.lblURL.AutoSize = true;
            this.lblURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblURL.Location = new System.Drawing.Point(119, 9);
            this.lblURL.Name = "lblURL";
            this.lblURL.Size = new System.Drawing.Size(79, 13);
            this.lblURL.TabIndex = 0;
            this.lblURL.Text = "Endereço url";
            // 
            // txtUrl
            // 
            this.txtUrl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUrl.Location = new System.Drawing.Point(122, 28);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(848, 21);
            this.txtUrl.TabIndex = 1;
            this.txtUrl.TextChanged += new System.EventHandler(this.txtUrl_TextChanged);
            // 
            // btnAcessar
            // 
            this.btnAcessar.Location = new System.Drawing.Point(1088, 27);
            this.btnAcessar.Name = "btnAcessar";
            this.btnAcessar.Size = new System.Drawing.Size(94, 23);
            this.btnAcessar.TabIndex = 2;
            this.btnAcessar.Text = "Acessar";
            this.btnAcessar.UseVisualStyleBackColor = true;
            this.btnAcessar.Click += new System.EventHandler(this.btnAcessar_Click);
            // 
            // grdDados
            // 
            this.grdDados.AllowUserToAddRows = false;
            this.grdDados.AllowUserToDeleteRows = false;
            this.grdDados.BackgroundColor = System.Drawing.SystemColors.Control;
            this.grdDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDados.Location = new System.Drawing.Point(35, 294);
            this.grdDados.Name = "grdDados";
            this.grdDados.ReadOnly = true;
            this.grdDados.Size = new System.Drawing.Size(1147, 258);
            this.grdDados.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(32, 278);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Retorno";
            // 
            // tabCtrlParams
            // 
            this.tabCtrlParams.Controls.Add(this.tabAutorizacao);
            this.tabCtrlParams.Controls.Add(this.tabParams);
            this.tabCtrlParams.Controls.Add(this.tabHeaders);
            this.tabCtrlParams.Location = new System.Drawing.Point(28, 85);
            this.tabCtrlParams.Name = "tabCtrlParams";
            this.tabCtrlParams.SelectedIndex = 0;
            this.tabCtrlParams.Size = new System.Drawing.Size(1158, 183);
            this.tabCtrlParams.TabIndex = 7;
            // 
            // tabAutorizacao
            // 
            this.tabAutorizacao.BackColor = System.Drawing.Color.Transparent;
            this.tabAutorizacao.Controls.Add(this.grpToken);
            this.tabAutorizacao.Controls.Add(this.cboTipoAutorizacao);
            this.tabAutorizacao.Controls.Add(this.label1);
            this.tabAutorizacao.Controls.Add(this.grpAutenticacao);
            this.tabAutorizacao.Location = new System.Drawing.Point(4, 22);
            this.tabAutorizacao.Name = "tabAutorizacao";
            this.tabAutorizacao.Padding = new System.Windows.Forms.Padding(3);
            this.tabAutorizacao.Size = new System.Drawing.Size(1150, 157);
            this.tabAutorizacao.TabIndex = 0;
            this.tabAutorizacao.Text = "Autorização";
            // 
            // grpToken
            // 
            this.grpToken.Controls.Add(this.btnObterToken);
            this.grpToken.Controls.Add(this.btnAutorizacaoLimparToken);
            this.grpToken.Controls.Add(this.txtAutorizacaoToken);
            this.grpToken.Controls.Add(this.txtAutorizacaoEsquema);
            this.grpToken.Controls.Add(this.label4);
            this.grpToken.Controls.Add(this.label5);
            this.grpToken.Location = new System.Drawing.Point(24, 44);
            this.grpToken.Name = "grpToken";
            this.grpToken.Size = new System.Drawing.Size(1105, 100);
            this.grpToken.TabIndex = 12;
            this.grpToken.TabStop = false;
            this.grpToken.Visible = false;
            // 
            // btnObterToken
            // 
            this.btnObterToken.Location = new System.Drawing.Point(993, 61);
            this.btnObterToken.Name = "btnObterToken";
            this.btnObterToken.Size = new System.Drawing.Size(94, 23);
            this.btnObterToken.TabIndex = 14;
            this.btnObterToken.Text = "Obter Token";
            this.btnObterToken.UseVisualStyleBackColor = true;
            this.btnObterToken.Click += new System.EventHandler(this.btnObterToken_Click);
            // 
            // btnAutorizacaoLimparToken
            // 
            this.btnAutorizacaoLimparToken.Location = new System.Drawing.Point(879, 61);
            this.btnAutorizacaoLimparToken.Name = "btnAutorizacaoLimparToken";
            this.btnAutorizacaoLimparToken.Size = new System.Drawing.Size(94, 23);
            this.btnAutorizacaoLimparToken.TabIndex = 4;
            this.btnAutorizacaoLimparToken.Text = "Limpar";
            this.btnAutorizacaoLimparToken.UseVisualStyleBackColor = true;
            this.btnAutorizacaoLimparToken.Click += new System.EventHandler(this.btnAutorizacaoLimparToken_Click);
            // 
            // txtAutorizacaoToken
            // 
            this.txtAutorizacaoToken.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAutorizacaoToken.Location = new System.Drawing.Point(82, 19);
            this.txtAutorizacaoToken.Multiline = true;
            this.txtAutorizacaoToken.Name = "txtAutorizacaoToken";
            this.txtAutorizacaoToken.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAutorizacaoToken.Size = new System.Drawing.Size(1005, 36);
            this.txtAutorizacaoToken.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtAutorizacaoToken, "Cole o token para utilizar na chamada ou clique em [Obter Token]");
            // 
            // txtAutorizacaoEsquema
            // 
            this.txtAutorizacaoEsquema.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAutorizacaoEsquema.Location = new System.Drawing.Point(82, 63);
            this.txtAutorizacaoEsquema.Name = "txtAutorizacaoEsquema";
            this.txtAutorizacaoEsquema.ReadOnly = true;
            this.txtAutorizacaoEsquema.Size = new System.Drawing.Size(94, 21);
            this.txtAutorizacaoEsquema.TabIndex = 3;
            this.txtAutorizacaoEsquema.Text = "Bearer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Esquema";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Token";
            // 
            // cboTipoAutorizacao
            // 
            this.cboTipoAutorizacao.BackColor = System.Drawing.SystemColors.Control;
            this.cboTipoAutorizacao.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoAutorizacao.FormattingEnabled = true;
            this.cboTipoAutorizacao.Items.AddRange(new object[] {
            "TOKEN",
            "BÁSICA",
            "SEM AUTORIZAÇÃO"});
            this.cboTipoAutorizacao.Location = new System.Drawing.Point(55, 17);
            this.cboTipoAutorizacao.Name = "cboTipoAutorizacao";
            this.cboTipoAutorizacao.Size = new System.Drawing.Size(145, 21);
            this.cboTipoAutorizacao.TabIndex = 10;
            this.cboTipoAutorizacao.SelectedIndexChanged += new System.EventHandler(this.cboTipoAutorizacao_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo";
            // 
            // grpAutenticacao
            // 
            this.grpAutenticacao.Controls.Add(this.btnAutorizacaoMostrarSenha);
            this.grpAutenticacao.Controls.Add(this.txtAutenticacaoSenha);
            this.grpAutenticacao.Controls.Add(this.txtAutenticacaoUsuario);
            this.grpAutenticacao.Controls.Add(this.label3);
            this.grpAutenticacao.Controls.Add(this.label2);
            this.grpAutenticacao.Location = new System.Drawing.Point(24, 44);
            this.grpAutenticacao.Name = "grpAutenticacao";
            this.grpAutenticacao.Size = new System.Drawing.Size(405, 100);
            this.grpAutenticacao.TabIndex = 11;
            this.grpAutenticacao.TabStop = false;
            this.grpAutenticacao.Visible = false;
            // 
            // btnAutorizacaoMostrarSenha
            // 
            this.btnAutorizacaoMostrarSenha.Location = new System.Drawing.Point(252, 54);
            this.btnAutorizacaoMostrarSenha.Name = "btnAutorizacaoMostrarSenha";
            this.btnAutorizacaoMostrarSenha.Size = new System.Drawing.Size(66, 23);
            this.btnAutorizacaoMostrarSenha.TabIndex = 4;
            this.btnAutorizacaoMostrarSenha.Text = "Esconder";
            this.btnAutorizacaoMostrarSenha.UseVisualStyleBackColor = true;
            this.btnAutorizacaoMostrarSenha.Click += new System.EventHandler(this.btnAutorizacaoMostrarSenha_Click);
            // 
            // txtAutenticacaoSenha
            // 
            this.txtAutenticacaoSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAutenticacaoSenha.Location = new System.Drawing.Point(67, 54);
            this.txtAutenticacaoSenha.Name = "txtAutenticacaoSenha";
            this.txtAutenticacaoSenha.Size = new System.Drawing.Size(179, 21);
            this.txtAutenticacaoSenha.TabIndex = 3;
            // 
            // txtAutenticacaoUsuario
            // 
            this.txtAutenticacaoUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAutenticacaoUsuario.Location = new System.Drawing.Point(67, 20);
            this.txtAutenticacaoUsuario.Name = "txtAutenticacaoUsuario";
            this.txtAutenticacaoUsuario.Size = new System.Drawing.Size(179, 21);
            this.txtAutenticacaoUsuario.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Senha";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Usuário";
            // 
            // tabParams
            // 
            this.tabParams.BackColor = System.Drawing.Color.Transparent;
            this.tabParams.Controls.Add(this.grdParametros);
            this.tabParams.Location = new System.Drawing.Point(4, 22);
            this.tabParams.Name = "tabParams";
            this.tabParams.Padding = new System.Windows.Forms.Padding(3);
            this.tabParams.Size = new System.Drawing.Size(1150, 157);
            this.tabParams.TabIndex = 1;
            this.tabParams.Text = "Parâmetros";
            // 
            // grdParametros
            // 
            this.grdParametros.BackgroundColor = System.Drawing.SystemColors.Control;
            this.grdParametros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdParametros.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Parâmetro,
            this.Valor});
            this.grdParametros.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdParametros.Location = new System.Drawing.Point(3, 3);
            this.grdParametros.Name = "grdParametros";
            this.grdParametros.Size = new System.Drawing.Size(1144, 151);
            this.grdParametros.TabIndex = 0;
            this.grdParametros.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdParametros_CellEndEdit);
            // 
            // Parâmetro
            // 
            this.Parâmetro.HeaderText = "Parâmetro";
            this.Parâmetro.Name = "Parâmetro";
            // 
            // Valor
            // 
            this.Valor.HeaderText = "Valor";
            this.Valor.Name = "Valor";
            // 
            // tabHeaders
            // 
            this.tabHeaders.Controls.Add(this.grdCabeçalhos);
            this.tabHeaders.Location = new System.Drawing.Point(4, 22);
            this.tabHeaders.Name = "tabHeaders";
            this.tabHeaders.Padding = new System.Windows.Forms.Padding(3);
            this.tabHeaders.Size = new System.Drawing.Size(1150, 157);
            this.tabHeaders.TabIndex = 2;
            this.tabHeaders.Text = "Cabeçalhos";
            this.tabHeaders.UseVisualStyleBackColor = true;
            // 
            // grdCabeçalhos
            // 
            this.grdCabeçalhos.BackgroundColor = System.Drawing.SystemColors.Control;
            this.grdCabeçalhos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdCabeçalhos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Key,
            this.Value});
            this.grdCabeçalhos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdCabeçalhos.Location = new System.Drawing.Point(3, 3);
            this.grdCabeçalhos.Name = "grdCabeçalhos";
            this.grdCabeçalhos.Size = new System.Drawing.Size(1144, 151);
            this.grdCabeçalhos.TabIndex = 0;
            // 
            // Key
            // 
            this.Key.HeaderText = "Chave";
            this.Key.Name = "Key";
            this.Key.ReadOnly = true;
            // 
            // Value
            // 
            this.Value.HeaderText = "Valor";
            this.Value.Name = "Value";
            this.Value.ReadOnly = true;
            // 
            // tabCtrlRetornos
            // 
            this.tabCtrlRetornos.Controls.Add(this.tabLog);
            this.tabCtrlRetornos.Controls.Add(this.tabSaida);
            this.tabCtrlRetornos.Location = new System.Drawing.Point(31, 559);
            this.tabCtrlRetornos.Name = "tabCtrlRetornos";
            this.tabCtrlRetornos.SelectedIndex = 0;
            this.tabCtrlRetornos.Size = new System.Drawing.Size(1156, 161);
            this.tabCtrlRetornos.TabIndex = 8;
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.txtLog);
            this.tabLog.Location = new System.Drawing.Point(4, 22);
            this.tabLog.Name = "tabLog";
            this.tabLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabLog.Size = new System.Drawing.Size(1148, 135);
            this.tabLog.TabIndex = 1;
            this.tabLog.Text = "Log / Erros";
            this.tabLog.UseVisualStyleBackColor = true;
            // 
            // txtLog
            // 
            this.txtLog.BackColor = System.Drawing.SystemColors.Control;
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLog.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtLog.Location = new System.Drawing.Point(3, 3);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(1142, 129);
            this.txtLog.TabIndex = 5;
            // 
            // tabSaida
            // 
            this.tabSaida.BackColor = System.Drawing.SystemColors.Control;
            this.tabSaida.Controls.Add(this.lblMsgSaida);
            this.tabSaida.Controls.Add(this.btnCopiarSaida);
            this.tabSaida.Controls.Add(this.label6);
            this.tabSaida.Controls.Add(this.txtTipoSaida);
            this.tabSaida.Controls.Add(this.txtSaída);
            this.tabSaida.Location = new System.Drawing.Point(4, 22);
            this.tabSaida.Name = "tabSaida";
            this.tabSaida.Padding = new System.Windows.Forms.Padding(3);
            this.tabSaida.Size = new System.Drawing.Size(1148, 135);
            this.tabSaida.TabIndex = 0;
            this.tabSaida.Text = "Saída (Bruta)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Tipo Saída:";
            // 
            // txtTipoSaida
            // 
            this.txtTipoSaida.Location = new System.Drawing.Point(72, 6);
            this.txtTipoSaida.Name = "txtTipoSaida";
            this.txtTipoSaida.ReadOnly = true;
            this.txtTipoSaida.Size = new System.Drawing.Size(124, 20);
            this.txtTipoSaida.TabIndex = 7;
            // 
            // txtSaída
            // 
            this.txtSaída.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaída.Location = new System.Drawing.Point(6, 32);
            this.txtSaída.Multiline = true;
            this.txtSaída.Name = "txtSaída";
            this.txtSaída.ReadOnly = true;
            this.txtSaída.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSaída.Size = new System.Drawing.Size(1136, 97);
            this.txtSaída.TabIndex = 6;
            // 
            // cboMetodo
            // 
            this.cboMetodo.BackColor = System.Drawing.SystemColors.Control;
            this.cboMetodo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMetodo.FormattingEnabled = true;
            this.cboMetodo.Items.AddRange(new object[] {
            "GET",
            "POST",
            "PUT",
            "DELETE"});
            this.cboMetodo.Location = new System.Drawing.Point(28, 28);
            this.cboMetodo.Name = "cboMetodo";
            this.cboMetodo.Size = new System.Drawing.Size(89, 21);
            this.cboMetodo.TabIndex = 9;
            this.cboMetodo.SelectedIndexChanged += new System.EventHandler(this.cboMetodo_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Método";
            // 
            // lblRetornoLinhas
            // 
            this.lblRetornoLinhas.Location = new System.Drawing.Point(976, 278);
            this.lblRetornoLinhas.Name = "lblRetornoLinhas";
            this.lblRetornoLinhas.Size = new System.Drawing.Size(210, 13);
            this.lblRetornoLinhas.TabIndex = 11;
            this.lblRetornoLinhas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnUrlLimpar
            // 
            this.btnUrlLimpar.Location = new System.Drawing.Point(976, 27);
            this.btnUrlLimpar.Name = "btnUrlLimpar";
            this.btnUrlLimpar.Size = new System.Drawing.Size(94, 23);
            this.btnUrlLimpar.TabIndex = 12;
            this.btnUrlLimpar.Text = "Limpar";
            this.btnUrlLimpar.UseVisualStyleBackColor = true;
            this.btnUrlLimpar.Click += new System.EventHandler(this.btnUrlLimpar_Click);
            // 
            // lblMensagem
            // 
            this.lblMensagem.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensagem.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblMensagem.Location = new System.Drawing.Point(27, 56);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(1155, 23);
            this.lblMensagem.TabIndex = 13;
            this.lblMensagem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCopiarSaida
            // 
            this.btnCopiarSaida.Location = new System.Drawing.Point(1048, 4);
            this.btnCopiarSaida.Name = "btnCopiarSaida";
            this.btnCopiarSaida.Size = new System.Drawing.Size(94, 23);
            this.btnCopiarSaida.TabIndex = 9;
            this.btnCopiarSaida.Text = "Copiar";
            this.btnCopiarSaida.UseVisualStyleBackColor = true;
            this.btnCopiarSaida.Click += new System.EventHandler(this.btnCopiarSaida_Click);
            // 
            // lblMsgSaida
            // 
            this.lblMsgSaida.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgSaida.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblMsgSaida.Location = new System.Drawing.Point(206, 6);
            this.lblMsgSaida.Name = "lblMsgSaida";
            this.lblMsgSaida.Size = new System.Drawing.Size(738, 21);
            this.lblMsgSaida.TabIndex = 14;
            this.lblMsgSaida.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsLblRodape});
            this.statusStrip1.Location = new System.Drawing.Point(0, 723);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1209, 22);
            this.statusStrip1.TabIndex = 14;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // stsLblRodape
            // 
            this.stsLblRodape.Name = "stsLblRodape";
            this.stsLblRodape.Size = new System.Drawing.Size(0, 17);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 150;
            this.toolTip1.ReshowDelay = 100;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // formPrincipal
            // 
            this.AcceptButton = this.btnAcessar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1209, 745);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.btnUrlLimpar);
            this.Controls.Add(this.lblRetornoLinhas);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cboMetodo);
            this.Controls.Add(this.tabCtrlRetornos);
            this.Controls.Add(this.tabCtrlParams);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.grdDados);
            this.Controls.Add(this.btnAcessar);
            this.Controls.Add(this.txtUrl);
            this.Controls.Add(this.lblURL);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formPrincipal";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "API Teste";
            this.Activated += new System.EventHandler(this.formPrincipal_Activated);
            this.Load += new System.EventHandler(this.formPrincipal_Load);
            this.Enter += new System.EventHandler(this.btnAutorizacaoMostrarSenha_Click);
            ((System.ComponentModel.ISupportInitialize)(this.grdDados)).EndInit();
            this.tabCtrlParams.ResumeLayout(false);
            this.tabAutorizacao.ResumeLayout(false);
            this.tabAutorizacao.PerformLayout();
            this.grpToken.ResumeLayout(false);
            this.grpToken.PerformLayout();
            this.grpAutenticacao.ResumeLayout(false);
            this.grpAutenticacao.PerformLayout();
            this.tabParams.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdParametros)).EndInit();
            this.tabHeaders.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdCabeçalhos)).EndInit();
            this.tabCtrlRetornos.ResumeLayout(false);
            this.tabLog.ResumeLayout(false);
            this.tabLog.PerformLayout();
            this.tabSaida.ResumeLayout(false);
            this.tabSaida.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblURL;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.Button btnAcessar;
        private System.Windows.Forms.DataGridView grdDados;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabControl tabCtrlParams;
        private System.Windows.Forms.TabPage tabAutorizacao;
        private System.Windows.Forms.TabPage tabParams;
        private System.Windows.Forms.TabControl tabCtrlRetornos;
        private System.Windows.Forms.TabPage tabSaida;
        private System.Windows.Forms.TextBox txtSaída;
        private System.Windows.Forms.TabPage tabLog;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.ComboBox cboMetodo;
        private System.Windows.Forms.ComboBox cboTipoAutorizacao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpAutenticacao;
        private System.Windows.Forms.TextBox txtAutenticacaoSenha;
        private System.Windows.Forms.TextBox txtAutenticacaoUsuario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpToken;
        private System.Windows.Forms.TextBox txtAutorizacaoToken;
        private System.Windows.Forms.TextBox txtAutorizacaoEsquema;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAutorizacaoMostrarSenha;
        private System.Windows.Forms.TabPage tabHeaders;
        private System.Windows.Forms.DataGridView grdCabeçalhos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Key;
        private System.Windows.Forms.DataGridViewTextBoxColumn Value;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTipoSaida;
        private System.Windows.Forms.Button btnAutorizacaoLimparToken;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblRetornoLinhas;
        private System.Windows.Forms.Button btnUrlLimpar;
        private System.Windows.Forms.DataGridView grdParametros;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parâmetro;
        private System.Windows.Forms.DataGridViewTextBoxColumn Valor;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Button btnObterToken;
        private System.Windows.Forms.Button btnCopiarSaida;
        private System.Windows.Forms.Label lblMsgSaida;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel stsLblRodape;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

